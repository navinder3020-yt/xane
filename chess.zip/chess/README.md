# Chess

A Pen created on CodePen.

Original URL: [https://codepen.io/viethoang012/pen/xRNgyM](https://codepen.io/viethoang012/pen/xRNgyM).

Chess for 2 players
+ Responsive design